package AutoSzalon;
import java.io.Serializable;
import java.util.Date;
//El��ll�tunk egy Aut t�pus� v�ltoz�t az adatokb�l.
//Adattagok
public class Aut implements Serializable {
	private int kod;
	private String szin;
	private int ar;
	private String marka;
	private String rendszam;
	private Date datum;
	
	
	//konstruktorok
	public Aut(int kod, String szin, int ar, String marka, String rendszam, Date datum) {
		super();
		this.kod = kod;
		this.szin = szin;
		this.ar = ar;
		this.marka = marka;
		this.rendszam = rendszam;
		this.datum = datum;
	}

	//Getter met�dusok
	public int getKod() {
		return kod;
	}

	public String getSzin() {
		return szin;
	}

	public int getAr() {
		return ar;
	}

	public String getMarka() {
		return marka;
	}

	public String getRendszam() {
		return rendszam;
	}

	public Date getDatum() {
		return datum;
	}
	
	

}
