package AutoSzalon;

//olyan oszt�ly, amely leellen�rzi, hogy a keres�kulcs megfelel�-e.
public class AutKer {
//lev�logat� met�dust, amely az adatokat tartalmaz� t�blamodellb�l �tm�solja a megfelel� rekordokat az eredm�ny t�blamodellbe (Select)
	public static boolean KeyCheck(String mezo, String key) {
		boolean vi = false;
		Character fc = ' ';
		String fs = "";

		if (mezo.equals("kod")) {
			if (key.substring(0, 1).equals("="))
				key = key.substring(1, key.length());
			vi = goodStoInt(key);
		}													//goodStoInt: sz�mm� alak�that� a kulcs?

		if (mezo.equals("szin")) {
			fs = key.substring(0, 1);
			if (Character.isLetter(key.charAt(0)) || fs.equals(" "))
				vi = true;
		}

		if (mezo.equals("marka")) {
			if (Character.isLetter(key.charAt(0)))
				vi = true;
		}
		if (mezo.equals("ar")) {
			fs = key.substring(0, 1);
			fc = key.charAt(0);
			if (fs.equals("<") || fs.equals(">") || fs.equals("=")) {
				if (key.length() > 1 && goodStoInt(key.substring(1, key.length())))
					vi = true;
				else
					vi = false;
			}
			if (Character.isDigit(fc) && key.indexOf("..") > 0) {
				int x = key.indexOf("..");
				String k1 = key.substring(0, x);
				String k2 = key.substring(x + 2, key.length());
				if (goodStoInt(k1) && goodStoInt(k2))
					vi = true;
				else
					vi = false;
			}
		}
		return vi;
	}

	public static AutTM Select(AutTM etm, String mezo, String key) {
		Object emptmn[] = { "Jel", "K�d", "Sz�n", "�r�", "M�rka", "Rendsz�m", "Beker�l�s Ideje" };
		AutTM kertm = new AutTM(emptmn, 0);
		String k = "", k1 = "", k2 = "";
		int x = 0;

		if (mezo.equals("kod") && key.substring(0, 1).equals("="))
			key = key.substring(1, key.length());
		if (mezo.equals("ar"))
			k = key.substring(1, key.length());
		if (mezo.equals("ar") && key.indexOf("..") > 0) {
			x = key.indexOf("..");
			k1 = key.substring(0, x);
			k2 = key.substring(x + 2, key.length());
		}
		for (int i = 0; i < etm.getRowCount(); i++) {
			if (mezo.equals("kod") && key.equals(etm.getValueAt(i, 1).toString()))
				Pack(etm, kertm, i);
			if (mezo.equals("szin") && etm.getValueAt(i, 2).toString().indexOf(key) >= 0)
				Pack(etm, kertm, i);
			if (mezo.equals("marka") && key.equals(etm.getValueAt(i, 4).toString()))
				Pack(etm, kertm, i);
			if (mezo.equals("ar") && key.substring(0, 1).equals("=") && k.equals(etm.getValueAt(i, 3).toString()))
				Pack(etm, kertm, i);
			if (mezo.equals("ar") && key.substring(0, 1).equals(">")
					&& FileManager.StoI(k) < FileManager.StoI(etm.getValueAt(i, 3).toString()))
				Pack(etm, kertm, i);
			if (mezo.equals("ar") && key.substring(0, 1).equals("<")
					&& FileManager.StoI(k) > FileManager.StoI(etm.getValueAt(i, 3).toString()))
				Pack(etm, kertm, i);
			if (mezo.equals("ar") && key.indexOf("..") > 0) {
				String s = etm.getValueAt(i, 3).toString();
				if (FileManager.StoI(k1) < FileManager.StoI(s) && FileManager.StoI(k2) > FileManager.StoI(s))
					Pack(etm, kertm, i);
			}
		} // == for ciklus v�ge
		return kertm;
	}

	public static void Pack(AutTM atm, AutTM kertm, int row) {
		kertm.addRow(new Object[] { new Boolean(false), FileManager.StoI(atm.getValueAt(row, 1).toString()),
				atm.getValueAt(row, 2).toString(), FileManager.StoI(atm.getValueAt(row, 3).toString()), atm.getValueAt(row, 4).toString(),
				 atm.getValueAt(row, 5).toString(),  atm.getValueAt(row, 6).toString()	 });
	}

	public static boolean goodStoInt(String s) {
		try {
			Integer.parseInt(s);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

}