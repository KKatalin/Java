package AutoSzalon;
import javax.swing.table.DefaultTableModel;

//Lista panel kialak�t�s ennek az oszt�ly seg�ts�g�vel
//t�bla modell l�trehoz�sa
public class AutTM extends DefaultTableModel {
	
	private static final long serialVersionUID = 1L;
	//Konstruktor: megkapja a mez�k nev�t �s a sorok sz�m�t.
	public AutTM(Object fildNames[] , int rows) {
		super(fildNames,rows);
	
	}
	
	//Szerkeszthet�s�g: a 0. oszlop minden sora szerkeszthet�, a t�bbi cella nem!
	public boolean isCellEditable(int row, int col) {
		if (col == 0) {return true;}
		return false;
	}
	
	//Oszlopok t�pusa: 0. oszlop logikai, a 2. eg�sz , a t�bbi sz�veges!
	public Class<?> getColumnClass(int index){
		if (index==0) return(Boolean.class);
		else if (index==2) return(Integer.class);
		return String.class;
		}

}
