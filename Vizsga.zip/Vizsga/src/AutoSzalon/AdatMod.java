package AutoSzalon;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class AdatMod extends JFrame implements ActionListener {
	private AutTM atm;
	private JPanel contentPane;
	private JTable table;
	private JLabel lblNewLabel;
	private JTextField szin;
	private JTextField ar;
	private JTextField marka;
	private JTextField rendszam;
	private JTextField bekerulesideje;
	private JButton modosit;
	private DataManager DM = new DataManager();
	private JScrollPane scrollPane;
	private JButton bezar;

	//Nem �n�ll�an futtathat� a panel,ez�rt nem kell bele a main f�ggv�ny!
	
	/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdatMod frame = new AdatMod(null); //Ideiglenes main f�ggv�ny,benne az �talak�tott AdatMod p�ld�nyos�t�s
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	*/
	
	//Mod�lis ablak, amelyet be kell z�rni ahhoz, hogy az alatta l�v� ablak �jra akt�v legyen!
	
	public AdatMod(JFrame f, AutTM betm) {  
		super("Aut�k m�dos�t�sa"); //ablak c�me
		atm= betm;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //az ablak bez�r�sakor lefut� met�dus
		setBounds(100, 100, 765, 300);  //ablak m�ret
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null); //elrendez�s szervez� kikapcsol�sa
		
		//Bez�r gomb
		bezar = new JButton("Bez\u00E1r");
		bezar.setActionCommand("bezar");
		bezar.setBounds(222, 230, 89, 23);
		contentPane.add(bezar);
		
		//Adunk a JTable-h�z egy JScrollPane-t
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 28, 730, 131);
		contentPane.add(scrollPane);
		
		//Adunk a panelhez egy JTable-t
		table = new JTable(atm); //A t�bl�zatban az atm modell fog megjelenni
		scrollPane.setViewportView(table);
		
		//Oszlopsz�less�g megad�sa: a teljes sz�less�get felosztja az itt megadott �rt�kek ar�ny�ban!
		TableColumn tc = null;
		for(int i = 0; i < 5; i++) {
		tc = table.getColumnModel().getColumn(i);
		if(i==0) tc.setPreferredWidth (30);
		else {tc.setPreferredWidth (120);}
	}
		
		table.setAutoCreateRowSorter(true); //AutoSorter bekapcsol�sa, a TableRowSorter azonnal l�trehoz�sra �s telep�t�sre ker�l a t�bl�ra. 
		
		lblNewLabel = new JLabel("A szalonunkban jelenleg kaphato aut\u00F3k:");
		lblNewLabel.setBounds(10, 3, 433, 14);
		contentPane.add(lblNewLabel);
		
		szin = new JTextField();
		szin.setBounds(138, 170, 107, 20);
		contentPane.add(szin);
		szin.setColumns(10);
		
		ar = new JTextField();
		ar.setColumns(10);
		ar.setBounds(251, 170, 107, 20);
		contentPane.add(ar);
		
		marka = new JTextField();
		marka.setColumns(10);
		marka.setBounds(368, 170, 107, 20);
		contentPane.add(marka);
		
		rendszam = new JTextField();
		rendszam.setColumns(10);
		rendszam.setBounds(485, 170, 107, 20);
		contentPane.add(rendszam);
		
		bekerulesideje = new JTextField();
		bekerulesideje.setColumns(10);
		bekerulesideje.setBounds(602, 170, 107, 20);
		contentPane.add(bekerulesideje);
		
		modosit = new JButton("M\u00F3dos\u00EDt");
		modosit.setActionCommand("modosit");
		modosit.setBounds(424, 230, 89, 23);
		contentPane.add(modosit);
		TableRowSorter<AutTM> trs= (TableRowSorter<AutTM>)table.getRowSorter(); // a felhaszn�l� az oszlopfejl�cre kattint, a t�bl�zat l�that�an rendez�dik.
		trs.setSortable(0, false); //A 0. oszlop rendezhet�s�g�nek letilt�sa
		esemenyHozzaad();
	}
	
	private void esemenyHozzaad() {
		this.bezar.addActionListener(this);
		this.modosit.addActionListener(this);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getActionCommand().equals("bezar")) {
			dispose(); //elt�nik a k�perny�r�l a panel, de a referenci�i megmaradnak. VAGY
			/* setVisible(false); //elt�nik a k�perny�r�l a panel, de a referenci�i megmaradnak. */
		}
		
		if(e.getActionCommand().equals("modosit")) {
			//Az adatokat csak a megkapott t�blamodellben m�dos�tjuk, a v�gleges ( perzisztens ) t�rol�shoz k�s�bb ki kell �rni �ket f�jlba
			//Csak egy adatsor, de annak ak�r az �sszes adata m�dos�that� egyszerre, ebb�l k�vetkeznek a M�dos�t�s gomb megnyom�sakor lezajl� ellen�rz�sek.
			//Hiba keletkezik,Ha nincs kit�ltve egyetlen m�dos�tand� adat sem, beker�l�s ideje mez�ben hib�s d�tum van, hib�s sz�m van az �r mez�ben, nincs kijel�lve m�dos�tand� rekord, ha t�bb rekord van kijel�lve
			if(!DM.filled(szin) && !DM.filled(ar) && !DM.filled(marka)
			&& !DM.filled (rendszam ) && !DM.filled(bekerulesideje)) DM.SMD("Egyetlen m�dos�t� adat sincs be�rva!" , 0);
			else if (DM.filled(bekerulesideje) && !DM.goodDate(bekerulesideje))
			DM.SMD("A Beker�l�s ideje id� mez�ben hib�s adat van!",0);
			else if (DM.filled(ar) && !DM.goodInt(ar))
			DM.SMD("Az �r mez�ben hib�s adat van!",0);
			else {
				int db =0, jel =0, x =0;
				for(x = 0; x < atm.getRowCount(); x++)
				if((Boolean)atm.getValueAt(x ,0)) { db ++; jel=x;}
				if(db ==0) DM.SMD("Nincs kijel�lve a m�dos�tand� rekord!", 0);
				if(db >1) DM.SMD("T�bb rekord van nEgyszerre csak egy rekord m�dos�that�!",0);
				if(db ==1)  {
				if(DM.filled(szin)) atm.setValueAt(DM.RF(szin), jel , 2);
				if(DM.filled (ar)) atm.setValueAt(DM.RF(ar), jel , 3);
				if(DM.filled (marka)) atm.setValueAt(DM.RF(marka), jel , 4);
				if(DM.filled (rendszam)) atm.setValueAt(DM.RF(rendszam), jel , 5);
				if(DM.filled (bekerulesideje)) atm.setValueAt(DM.RF(bekerulesideje), jel , 6);
				DM.SMD("A rekord m�dos�tva!",1);
				DM.DF(szin); DM.DF(ar); DM.DF(marka); DM.DF(rendszam);  DM.DF(bekerulesideje);
				atm.setValueAt(false, jel, 0);
				
				}
				} 
		}
	}

}

