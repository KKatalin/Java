package AutoSzalon;
import java.text.ParseException;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class DataManager {
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
	//Ez egy olyan met�dus,amivel �zenetpanelt tudunk megjelen�teni.
	//A met�dus neve SMD, param�terei:megjelen�tend� �zenet,ikon t�pusa (int).
	public static void SMD( String mes , int type ) {
		JOptionPane.showMessageDialog(null , mes , "Program �zenet", type);
		}
	//String beolvas�sa sz�vegmez�b�l
		public static String RF (JTextField a) {
		return a.getText().toString();
		}
		
		//Van adat a mez�ben?
		/*public boolean filled (JTextField a) {
		String s = RF(a);
		if(s.length () > 0) return true ; else return false;
		}
		*/
		public static boolean filled(JTextField a) {
			String s = RF(a);
			if (s.length() > 0)
				return true;
			else
				return false;
		}
		
		//Helyes e a d�tum? (����.HH.NN)
		public boolean goodDate(JTextField a) {
		String s = RF(a);
		Date testDate = null;
		try {
		testDate = sdf .parse (s);
		}
		catch (ParseException e){ return false;}
		if(sdf.format(testDate).equals(s)) return true ;
		else return false;
		}
		
		//Helyes az eg�sz sz�m?
		public static boolean goodInt (JTextField a) {
		String s = RF(a);
		try {
		Integer.parseInt(s); return true;
		}
		catch (NumberFormatException e){ return false;}
		
	}
	
		//stringb�l integer
		public int StoI (String s){
		int x=-55;
		x =Integer.parseInt (s);
		return x;
		}
		
		//Stringb�l d�tum
		public Date StoD(String s){
		Date testDate = null, vid = null;
		try{
		testDate = sdf.parse (s);
		}
		catch (ParseException e) { return vid;}
		if(!sdf.format(testDate).equals(s)) {return vid;}
				return testDate;
		}
		// sz�vegmez�t ki�r�t� met�dus
		public static void DF (JTextField a) {
		a.setText("");
		}
		
		
}
