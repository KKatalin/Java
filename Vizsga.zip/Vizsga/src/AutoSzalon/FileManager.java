package AutoSzalon;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;

import javax.swing.JOptionPane;

//Egy k�l�n oszt�lyba tessz�k a f�jlkezel� rutinokat
//A rutin megkapja a beolvasand� f�jl nev�t, �s a t�blamodell nev�t
//Beolvassa az adatokat, soronk�nt hozz�adja a t�blamodellhez, �s visszaadja a t�blamodellt

public class FileManager {
	public static int StoI (String s){
		int x=-55;
		x = Integer.parseInt (s);
		return x;
		}
	
	public static void CsvReader (File fnev , AutTM atm ) {
		DataManager DM = new DataManager();
	
	try {
	BufferedReader in = new BufferedReader (new FileReader (fnev)); //pufferelt sz�vegolvas�. A f�jlb�l egyszerre max . 1024 kB ot olvas be a mem�ri�ba, �s onnan lehet soronk�nt kiolvasni az adatokat.
	String s= in.readLine (); //=== mez�nevek az els� sorb�l
	s=in.readLine (); //=== adatsor
	
	//am�g van sor addig...
	while(s!=null) {
	String[] st = s.split(";"); //ahol ";" van ott sz�tv�lasztja az adatokat a t�bl�zat cell�j�ban
	atm.addRow(new Object[] {false, StoI(st[0]), st[1], StoI(st[2]), st[3], st[4],  st[5]}); //addRow: sor hozz�ad�sa a t�blamodellhez
	s=in.readLine (); //...ADDIG OLVASSA BE A SOROKAT
	}
	in.close(); //F�JL BEOLVAS� BEZ�R�SA
	DM.SMD("Adatok beolvasva!", 1); //�zenet h az adat beolvasva
	}
	catch (IOException ioe ) {
	DM.SMD("CsvReader: "+ ioe.getMessage (), 0); //ha nem siker�lt beolvasni akkor hib�t dob
	}
	
	}
	
	public static void CsvWriter(String fnev, AutTM atm) {
		DataManager DM = new DataManager();
		try {
			PrintStream out = new PrintStream(new FileOutputStream(fnev));
			out.println("K�d;Sz�n;�r;M�rka;Rendsz�m;Beker�l�s ideje");
			int rdb = atm.getRowCount();
			int cdb = atm.getColumnCount();
			for (int i = 0; i < rdb; i++) {
				for (int j = 1; j < cdb - 1; j++) {
					out.print("" + atm.getValueAt(i, j) + ";");
				}
				out.println("" + atm.getValueAt(i, cdb - 1));
			}
			out.close();
			DM.SMD("Adatok ki�rva!", 1);
		} catch (IOException ioe) {
			DM.SMD("CsvWriter: " + ioe.getMessage(), 0);
		}
	}
}
