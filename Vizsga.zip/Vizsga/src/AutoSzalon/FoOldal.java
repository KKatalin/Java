package AutoSzalon;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;



import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import java.awt.Font;

public class FoOldal extends JFrame implements ActionListener {
	private JTextField fnev;
	private JTextField fdb;
	private String forras ="V�lasszon!";
	private File fbe;
	private DataManager DM = new DataManager();
	private AutTM atm;
	private SimpleDateFormat sdf = new SimpleDateFormat ("yyyy.MM.dd");
	private JTextField kifnev;
	private String cel ="V�lasszon!";
	private JLabel lbldvzljkAutszalonunkban;
	private JButton bb;
	private JButton bl;
	private JButton ujadat;
	private JButton modosit;
	private JButton torol;
	private JButton kiir;
	private JComboBox jcbf;
	private JLabel lblNewLabel;
	private JLabel lblAdatokSzma;
	private JLabel lblCl;
	private JComboBox jcbc;
	private JButton bz;
	private JRadioButton marka;
	private JRadioButton ar;
	private JRadioButton kod;
	private JRadioButton szin;
	private JLabel lblX;
	private JButton keres;
	private String kerkif = "kod";
	private AutTM kertm;
	private JTextField kulcs;

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FoOldal frame = new FoOldal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FoOldal() {
		getContentPane().setBackground(new Color(240, 255, 240)); //ablak h�tt�rsz�n
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //az ablak bez�r�sakor lefut� met�dus
		setBounds(100, 100, 450, 300); //ablak m�ret
		getContentPane().setLayout(null); //elrendez�s szervez� kikapcsol�sa
		
		//Bet�lt�s gomb l�trehoz�sa
		bb = new JButton("Bet\u00F6lt\u00E9s");
		bb.setActionCommand("bb");
		bb.setBounds(20, 20, 100, 24); //Bet�lt�s gomb elhelyez�se 
		getContentPane().add(bb); // bet�lt�s gomb l�that�s�ga, hozz�adjuk az ablakhoz
		
		//Lista Gomb l�trehoz�sa
		bl = new JButton("Lista");
		bl.setActionCommand("bl");
		bl.setBounds(20, 55, 100, 24);
		getContentPane().add(bl);
		
		//bez�r gomb
		bz = new JButton("Bez\u00E1r");
		bz.setActionCommand("bz");
		bz.setBounds(324, 229, 100, 24);
		getContentPane().add(bz);
		
		lblNewLabel = new JLabel("Forr\u00E1s");
		lblNewLabel.setBounds(130, 25, 46, 14);
		getContentPane().add(lblNewLabel);
		
		lblAdatokSzma = new JLabel("Adatok sz\u00E1ma:");
		lblAdatokSzma.setBounds(130, 60, 93, 14);
		getContentPane().add(lblAdatokSzma);
		
		String elem [] = {"V�lasszon!","Helyi dat f�jl",
				"Helyi .xml f�jl","Helyi.csv f�jl","SQLite DB",
				"Web: JSON f�jl"};
		
		jcbf = new JComboBox();
		for (String s : elem) jcbf.addItem (s);
		jcbf.setActionCommand("jcbf");
		jcbf.setBounds(178, 21, 138, 22);
		getContentPane().add(jcbf);
		
		fnev = new JTextField();
		fnev.setBounds(324, 22, 100, 20);
		getContentPane().add(fnev);
		fnev.setColumns(10);
		
		fdb = new JTextField();
		fdb.setHorizontalAlignment(SwingConstants.RIGHT);
		fdb.setText("0");
		fdb.setBounds(233, 57, 71, 20);
		getContentPane().add(fdb);
		fdb.setColumns(10);
		
		lbldvzljkAutszalonunkban = new JLabel("\u00DCdv\u00F6z\u00F6lj\u00FCk aut\u00F3szalonunkban!");
		lbldvzljkAutszalonunkban.setBounds(110, 0, 274, 14);
		getContentPane().add(lbldvzljkAutszalonunkban);
		
		ujadat = new JButton("\u00DAj adat");
		ujadat.setActionCommand("ujadat");
		ujadat.setBounds(20, 90, 100, 24);
		getContentPane().add(ujadat);
		
		modosit = new JButton("M\u00F3dos\u00EDt\u00E1s");
		modosit.setActionCommand("modosit");
		modosit.setBounds(20, 127, 100, 24);
		getContentPane().add(modosit);
		
		torol = new JButton("T\u00F6rl\u00E9s");
		torol.setActionCommand("torol");
		torol.setBounds(20, 162, 100, 24);
		getContentPane().add(torol);
		
		
		kiir = new JButton("Ki\u00EDr\u00E1s");
		kiir.setActionCommand("kiir");
		kiir.setBounds(20, 197, 100, 24);
		getContentPane().add(kiir);
		
		lblCl = new JLabel("C\u00E9l");
		lblCl.setBounds(130, 202, 46, 14);
		getContentPane().add(lblCl);
		
		
		String elem2[] = {"V�lasszon!",">>> Forr�s","Helyi.dat f�jl",
				"Helyi.xml f�jl","Helyi.csv f�jl","Helyi.json f�jl",
				"Helyi.pdf f�jl","SQLite DB"};
		jcbc = new JComboBox();
		for (String s: elem2) jcbc .addItem(s);
		jcbc.setActionCommand("jcbc");
		jcbc.setBounds(178, 198, 138, 22);
		getContentPane().add(jcbc);
		
		kifnev = new JTextField();
		kifnev.setColumns(10);
		kifnev.setBounds(324, 199, 100, 20);
		getContentPane().add(kifnev);
		
		//atm p�ld�nyos�t�sa mez�nevekkel, 0 darab sorral
		Object auttmn [] = {"Jel", "K�d"," Sz�n ","�r", "M�rka", "Rendsz�m", "Beker�l�s ideje"};
		atm = new AutTM(auttmn ,0);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(148, 101, 276, 85);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		kod = new JRadioButton("K\u00F3d");
		kod.setActionCommand("jrbkod");
		kod.setBounds(6, 7, 56, 25);
		panel.add(kod);
		
		szin = new JRadioButton("Sz\u00EDn");
		szin.setActionCommand("jrbszin");
		szin.setBounds(60, 7, 56, 25);
		panel.add(szin);
		
		ar = new JRadioButton("\u00C1r");
		ar.setActionCommand("jrbar");
		ar.setBounds(120, 7, 49, 25);
		panel.add(ar);
		
		marka = new JRadioButton("M\u00E1rka");
		marka.setActionCommand("jrbmarka");
		marka.setBounds(187, 7, 83, 25);
		panel.add(marka);

		
		lblX = new JLabel("X=");
		lblX.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblX.setBounds(10, 41, 56, 16);
		panel.add(lblX);
		
		keres = new JButton("Keres\u00E9s");
		keres.setActionCommand("keres");
		keres.setBounds(168, 41, 97, 25);
		panel.add(keres);
		
		kulcs = new JTextField();
		kulcs.setColumns(10);
		kulcs.setBounds(39, 39, 116, 22);
		panel.add(kulcs);
		
		
		esemenyHozzaad();
		
		
	}
	private void esemenyHozzaad() {
		this.bb.addActionListener(this);
		this.bl.addActionListener(this);
		this.bz.addActionListener(this);
		this.jcbf.addActionListener(this);
		this.ujadat.addActionListener(this);
		this.modosit.addActionListener(this);
		this.torol.addActionListener(this);
		this.kiir.addActionListener(this);
		this.jcbc.addActionListener(this);
		this.kod.addActionListener(this);
		this.szin.addActionListener(this);
		this.ar.addActionListener(this);
		this.marka.addActionListener(this);
		this.keres.addActionListener(this);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("bb")) {
			if(forras.equals ("V�lasszon!"))
			DM.SMD("El�sz�r v�lassza ki a Forr�st!", 0); //Ha nincs kiv�lasztva forr�s, a Bet�lt�s megnyom�s�ra hiba�zenetet ad(DM.SDM->DataManager)
			//Ha kiv�lasztjuk a Helyi.cs f�jl fel�ratot a v�laszt�panelb�l, akkor...
			if(forras.equals ("Helyi.csv f�jl")) {
			FileDialog fd = new FileDialog (new Frame(), " ", FileDialog.LOAD); //FileDialog p�ld�nyos�t�sa
			fd.setFile("*.csv"); //Csak csv f�jlok jelenjenek meg
			fd.setVisible(true); //FileDialog l�that�v� t�tele
			//ha a visszaadott f�jl nem null, azaz a felhaszn�l� kiv�lasztotta a f�jlt
			if(fd.getFile() != null) {
			fbe = new File (fd.getDirectory(), fd.getFile()); //K�nyvt�r �s f�jln�v , egy�tt a f�jl
			String befnev = fd.getFile(); //Megkapja a f�jl p�rbesz�dpanel kiv�lasztott f�jlj�t.
			fnev.setText(befnev);
			//Importok sz�ks�gesek a FileDialog �s a File miatt, �s kell az fbe v�ltoz� deklar�ci�ja is!
			FileManager.CsvReader(fbe , atm); //file manager oszt�ly seg�ts�g�vel a beolvasott csvfile megjelen�t�se
			}
			}
			fdb.setText(""+atm.getRowCount()); //Visszaadja az adatt�bla sorainak sz�m�t.
			}
		
		if(e.getActionCommand().equals("bl")) {
			Raktar al = new Raktar (FoOldal.this , atm); //P�ld�nyos�t�s
			al.setVisible(true); //Megjelen�t�s
		}
		
		if(e.getActionCommand().equals("bz")) {
			System.exit(0);  // hibamentes kil�p�s
		}
		
		if(e.getActionCommand().equals("jcbf")) {
			forras= (String)jcbf.getSelectedItem();
			fnev.setText(forras);
			fdb.setText("4");
		}
		
		if(e.getActionCommand().equals("ujadat")) {
			SimpleDateFormat sdf = new SimpleDateFormat ("yyyy.MM.dd");
			//Ha nincs adat, a k�d �rt�ke 20, egy�bk�nt a t�bl�zatban l�v� utols� adatsorban l�v� k�d �rt�ke.
			int kodv=0;
			if (atm.getRowCount()==0) kodv=20;
			else kodv=(int)atm.getValueAt (atm.getRowCount()-1, 1);
			UjAuto au = new UjAuto(FoOldal.this, kodv);
			au.setVisible(true);
			//Adat kiolvas�sa az �j adat panelr�l
			int kilep = au.KiLep();
			if (kilep==1) {
				Aut ujAuto = au.getAut();
				Date d = ujAuto.getDatum();
				String ddd = sdf.format(d).toString(); //d�tum helyes form�tuma, fent megadtuk a helyes �rt�ket �s tostringgel fel�l�rtuka d�tum t�pust
			atm.addRow(new Object[]{new Boolean (false), ujAuto.getKod(), 
					ujAuto.getSzin(), ujAuto.getAr(), ujAuto.getMarka(), ujAuto.getRendszam(), ddd});
			fdb.setText(""+atm.getRowCount());
			}
		
		}
		
		if(e.getActionCommand().equals("modosit")) {
			if(atm.getRowCount ()==0) DM.SMD("Nincs m�dos�that� adat!", 0);
			else {
			AdatMod am = new AdatMod(FoOldal.this, atm);
			am.setVisible(true);
			}
		
		}
		
		if(e.getActionCommand().equals("torol")) {
			if(atm.getRowCount()==0) DM.SMD("Nincs t�r�lhet� adat!", 0);
			else {
			AutTor at = new AutTor (FoOldal.this , atm);
			at.setVisible(true);
			fdb.setText(""+ atm.getRowCount());
			}
		}
		
		if(e.getActionCommand().equals("kiir")) {
			//Ha kiv�lasztjuk ezt az opci�t, �s nincs kiv�lasztva Forr�s , hiba�zenetet ad!
			if(cel.equals ("V�lasszon!")) DM.SMD("El�sz�r v�lassza ki a C�lt!", 0);
			else
			if (atm.getRowCount()==0) DM.SMD("Nincs ki�rhat� adat", 0);
			else
			if(cel.equals("Helyi.csv f�jl")) {
			if(kifnev.getText().length()==0) DM.SMD("Nincs megadva a c�l f�jl neve!", 0);
			else {
				FileManager.CsvWriter(kifnev.getText().toString (), atm);
			}
			}
		}
		
		if(e.getActionCommand().equals("jcbc")) {
			cel= (String)jcbc.getSelectedItem(); //c�l kiv�laszt�sa, leg�rd�l� list�ban h mik vannak
		}
		//1. A keres�s az etm t�blamodellben fog keresni, �s a tal�lat rekordokat �tm�solja egy m�sik t�blamodellbe (kertm), melyet megjelen�t�nk a keres�s tal�lati panelen.
		//2. A keres�s ind�t�sakor ellen�rizz�k le, hogy:
			//1. L�teznek-e adatsorok?
	    	//2. Ki van-e t�ltve a keres�kulcs mez�?
			//3. Helyesen van-e megadva a keres�kulcs?
		
		if (e.getActionCommand().equals("jrbkod")) {
			if (this.kod.isSelected())
				kerkif = "kod";
		}

		if (e.getActionCommand().equals("jrbszin")) {
			if (this.szin.isSelected())
				kerkif = "szin";
		}

		if (e.getActionCommand().equals("jrbmarka")) {
			if (this.marka.isSelected())
				kerkif = "marka";
		}

		if (e.getActionCommand().equals("jrbar")) {
			if (this.ar.isSelected())
				kerkif = "ar";
		}
		
		if (e.getActionCommand().equals("keres")) {
		if (DataManager.RF(fdb).equals("0")) DM.SMD("Nincs bet�lt�tt adat!", 0);
		else if (!DataManager.filled(kulcs)) DM.SMD("A keres�kulcs (X=) nincs megadva!", 0);
		else if (!AutKer.KeyCheck(kerkif, DataManager.RF(kulcs))) DM.SMD("A keres�kulcs hib�san van megadva!", 0);
		else {
		kertm = AutKer.Select(atm, kerkif, DataManager.RF(kulcs));
		AutKerP ak = new AutKerP(FoOldal.this, kertm, kerkif,
				DataManager.RF(kulcs));
		ak.setVisible(true);
		}

		} 

	}
			
		
	}
	

