package AutoSzalon;
import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UjAuto extends JDialog {
	private JTextField kod;
	private JTextField szin;
	private JTextField ar;
	private JTextField marka;
	private JTextField datum;
	private JTextField rendszam;
	private int kilep=0;
	private Aut adat;
	private JLabel lbljAdatFelvitele;
	private JLabel lblNewLabel;
	private JButton leker;
	private JLabel lblSzn;
	private JLabel lblr;
	private JLabel lblMrka;
	private JLabel lblRendszm;
	private JLabel lblBekerlsDtuma;
	private JLabel lblhhnn;
	private JButton beszur;
	private JButton bezar;

	/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UjAuto dialog = new UjAuto(null,52);
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	public UjAuto(JFrame f, int maxKod) {
		super(f, true);
		setTitle("\u00DAj Aut\u00F3 Felv\u00E9tele");
		getContentPane().setBackground(new Color(240, 255, 255));
		setBounds(100, 100, 450, 370);
		getContentPane().setLayout(null);
		
		lblNewLabel = new JLabel("K\u00F3d:");
		lblNewLabel.setFont(new Font("Marcellus SC", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 35, 53, 18);
		getContentPane().add(lblNewLabel);
		
		lbljAdatFelvitele = new JLabel("\u00DAj adat felvitele:");
		lbljAdatFelvitele.setFont(new Font("Marcellus SC", Font.PLAIN, 14));
		lbljAdatFelvitele.setBounds(10, 0, 186, 18);
		getContentPane().add(lbljAdatFelvitele);
		
		lblSzn = new JLabel("Sz\u00EDn:");
		lblSzn.setFont(new Font("Marcellus SC", Font.PLAIN, 14));
		lblSzn.setBounds(10, 75, 53, 18);
		getContentPane().add(lblSzn);
		
		lblr = new JLabel("\u00C1r:");
		lblr.setFont(new Font("Marcellus SC", Font.PLAIN, 14));
		lblr.setBounds(10, 112, 53, 18);
		getContentPane().add(lblr);
		
		lblMrka = new JLabel("M\u00E1rka:");
		lblMrka.setFont(new Font("Marcellus SC", Font.PLAIN, 14));
		lblMrka.setBounds(10, 150, 64, 18);
		getContentPane().add(lblMrka);
		
		lblBekerlsDtuma = new JLabel("Beker\u00FCl\u00E9s d\u00E1tuma:");
		lblBekerlsDtuma.setFont(new Font("Marcellus SC", Font.PLAIN, 14));
		lblBekerlsDtuma.setBounds(10, 236, 153, 18);
		getContentPane().add(lblBekerlsDtuma);
		
		//ki vannak e t�ltve a mez�k?, a beker�l�s d�tuma d�tum t�pus� e?, az �r mez�ben eg�sz sz�m van?
		//ezek a met�dusok a DataManagerb�l h�v�dnak meg
		beszur = new JButton("Besz\u00FAr");
		beszur.addActionListener(new ActionListener() {
			private DataManager DM = new DataManager();
			public void actionPerformed(ActionEvent e) {
				if (!DM.filled (kod)) kod.setText(""+( maxKod +1));
				if(!DM.filled (szin)) DM.SMD("A Sz�n mez� �res!", 0);
				else
				if (!DM.filled (ar)) DM.SMD("Az �r mez� �res!", 0);
				else
				if (!DM .goodInt (ar)) DM.SMD("Az �r mez�ben hib�s adat van!", 0);
				else
				if (!DM.filled (marka)) DM.SMD("A M�rka mez� �res!", 0);
				else
				if (!DM.filled (rendszam)) DM.SMD("A Rendsz�m mez� �res!", 0);
				else
				if (!DM.filled (datum)) DM.SMD("A Beker�l�s d�tuma mez� �res!", 0);
				else
				if (!DM.goodDate(datum)) DM.SMD("A Beker�l�s d�tuma mez�ben hib�s adat van!", 0);
				else {
					adat= new Aut(DM.StoI(DM.RF(kod)), DM.RF(szin), DM.StoI(DM.RF(ar)), DM.RF(marka), DM.RF(rendszam) ,DM.StoD(DM.RF(datum)));
				DM.SMD("Adat besz�rva!", 1);
				kilep=1;
				dispose();
				setVisible(false);
				}
			}
		});
		beszur.setBounds(59, 300, 89, 23);
		getContentPane().add(beszur);
		
		//bez�r gomb
		bezar = new JButton("Bez\u00E1r");
		bezar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		bezar.setBounds(275, 300, 89, 23);
		getContentPane().add(bezar);
		
		//sz�vegmez�, �s annak v�ltoz�nev�nek be�ll�t�sa egyedire
		kod = new JTextField();
		kod.setEditable(false);
		kod.setBounds(62, 35, 64, 20);
		getContentPane().add(kod);
		kod.setColumns(10);
		
		szin = new JTextField();
		szin.setBounds(63, 75, 240, 20);
		getContentPane().add(szin);
		szin.setColumns(10);
		
		ar = new JTextField();
		ar.setColumns(10);
		ar.setBounds(63, 112, 110, 20);
		getContentPane().add(ar);
		
		marka = new JTextField();
		marka.setColumns(10);
		marka.setBounds(63, 150, 240, 20);
		getContentPane().add(marka);
		
		datum = new JTextField();
		datum.setColumns(10);
		datum.setBounds(140, 236, 110, 20);
		getContentPane().add(datum);
		
		rendszam = new JTextField();
		rendszam.setBounds(86, 190, 110, 20);
		getContentPane().add(rendszam);
		rendszam.setColumns(10);
		
		//A Lek�r gomb jelen�ti meg a rekord k�dj�t. A legnagyobb l�tez� k�dot ( maxKod ) a Main-t�l kapja meg, ett�l eggyel nagyobb a rekord k�dja.
		leker = new JButton("Lek\u00E9r");
		leker.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				kod.setText(""+(maxKod+1));
			}
		});
		leker.setBounds(157, 34, 89, 23);
		getContentPane().add(leker);
		
		lblhhnn = new JLabel("\u00E9\u00E9\u00E9\u00E9.hh.nn.");
		lblhhnn.setFont(new Font("Marcellus SC", Font.PLAIN, 14));
		lblhhnn.setBounds(275, 238, 95, 18);
		getContentPane().add(lblhhnn);
		
		lblRendszm = new JLabel("Rendsz\u00E1m:");
		lblRendszm.setFont(new Font("Marcellus SC", Font.PLAIN, 14));
		lblRendszm.setBounds(10, 190, 77, 18);
		getContentPane().add(lblRendszm);
		
		

	}
	
	// k�t met�dus amivel ki tudjuk olvasni a panel adatait
	
	public Aut getAut() {
	return adat;
	}
	public int KiLep () {
	return kilep;
	}

}
