package AutoSzalon;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JCheckBox;

public class AutTor extends JFrame implements ActionListener{
	private AutTM atm;
	private JPanel contentPane;
	private JTable table;
	private boolean md=false; //A t�bbes t�rl�s v�ltoz�j�nak deklar�l�sa
	private DataManager DM = new DataManager(); //datam. p�ld�ny
	private JLabel lblNewLabel;
	private JScrollPane scrollPane;
	private JCheckBox jcb;
	private JButton torol;
	private JButton bezar;

	//Nem �n�ll�an futtathat� a panel,ez�rt nem kell bele a main f�ggv�ny!
	/*
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Raktar frame = new Raktar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	*/
	//Mod�lis ablak, amelyet be kell z�rni ahhoz, hogy az alatta l�v� ablak �jra akt�v legyen!
	public AutTor(JFrame f , AutTM betm) {
		super("Aut�k t�rl�se"); //ablak c�me
		atm= betm;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //az ablak bez�r�sakor lefut� met�dus
		setBounds(100, 100, 765, 300);  //ablak m�ret
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null); //elrendez�s szervez� kikapcsol�sa
		
		//Bez�r gomb
		bezar = new JButton("Bez\u00E1r");
		bezar.setActionCommand("bezar");
		bezar.setBounds(301, 230, 89, 23);
		contentPane.add(bezar);
		
		//Adunk a JTable-h�z egy JScrollPane-t
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 28, 730, 141);
		contentPane.add(scrollPane);
		
		//Adunk a panelhez egy JTable-t
		table = new JTable(atm); //A t�bl�zatban az atm modell fog megjelenni
		scrollPane.setViewportView(table);
		
		//Oszlopsz�less�g megad�sa: a teljes sz�less�get felosztja az itt megadott �rt�kek ar�ny�ban!
		TableColumn tc = null;
		for(int i = 0; i < 6; i++) {
		tc = table.getColumnModel().getColumn(i);
		if(i==0 || i==1) tc.setPreferredWidth (30);
		else {tc.setPreferredWidth (120);}
	}
		
		table.setAutoCreateRowSorter(true); //AutoSorter bekapcsol�sa, a TableRowSorter azonnal l�trehoz�sra �s telep�t�sre ker�l a t�bl�ra. 
		
		lblNewLabel = new JLabel("A szalonunkban jelenleg kaphato aut\u00F3k:");
		lblNewLabel.setBounds(10, 3, 433, 14);
		contentPane.add(lblNewLabel);
		
		jcb = new JCheckBox("T\u00F6bb rekord is t\u00F6r\u00F6lhet\u0151 egyszerre");
		jcb.setActionCommand("jcb");
		jcb.setBounds(6, 194, 232, 23);
		contentPane.add(jcb);
		
		torol = new JButton("T\u00F6r\u00F6l");
		torol.setActionCommand("torol");
		torol.setBounds(131, 230, 89, 23);
		contentPane.add(torol);
		TableRowSorter<AutTM> trs= (TableRowSorter<AutTM>)table.getRowSorter(); // a felhaszn�l� az oszlopfejl�cre kattint, a t�bl�zat l�that�an rendez�dik.
		trs.setSortable(0, false); //A 0. oszlop rendezhet�s�g�nek letilt�sa
		esemenyHozzaad();
	}
	private void esemenyHozzaad() {
		this.bezar.addActionListener(this);
		this.jcb.addActionListener(this);
		this.torol.addActionListener(this);
		
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("bezar")) {
			dispose(); //elt�nik a k�perny�r�l a panel, de a referenci�i megmaradnak. VAGY
			/* setVisible(false); //elt�nik a k�perny�r�l a panel, de a referenci�i megmaradnak. */
		}
		
		if(e.getActionCommand().equals("jcb")) {
			//md v�ltoz�, ami a t�bbes t�rl�s funkci� �llapot�t mutatja 
			md= jcb.isSelected(); //Visszaadja a gomb �llapot�t. Igaz, ha a kapcsol�gomb ki van v�lasztva, hamis, ha nincs.
		}
		
		if(e.getActionCommand().equals("torol")) {
			int db =0, jel =0, x =0;
			for(x = 0; x < atm.getRowCount(); x++)
			if ((Boolean)atm.getValueAt(x ,0))  {db ++; jel=x;}
			if(db ==0) DM.SMD("Nincs kijel�lve a t�rlend� rekord!", 0);
			if(!md ) {
			if(db >1) DM.SMD("T�bb rekord van kijel�lve! Egyszerre csak egy rekord t�r�lhet�!", 0);
			
			if(db ==1) {
			atm.removeRow(jel);
			DM.SMD("A rekord t�r�lve!",1);
			}
			}
			else {
			for(int i =0; i<atm.getRowCount (); i ++)
			if((Boolean)atm.getValueAt(i ,0)) { atm .removeRow(i); i--;}
			DM.SMD("Rekord(ok) t�r�lve!", 1);
			}
		
		}
	}
}

